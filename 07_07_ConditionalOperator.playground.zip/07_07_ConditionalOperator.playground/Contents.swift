import UIKit

let goodPizza = "This is good Pizza"
let badPizza = "This is bad Pizza"
var rating:Int! = 5
var pizzaRating = ""

if rating > 5 {
    pizzaRating = goodPizza
} else {
    pizzaRating = badPizza
}

print(pizzaRating)
